PrimBett Demo
Toto je iba ukážková štruktúra projektu.